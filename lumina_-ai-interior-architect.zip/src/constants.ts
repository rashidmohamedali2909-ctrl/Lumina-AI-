export const VAASTU_PROMPT = `
Analyze the provided room image for Vaastu Shastra compliance. 
1. Identify the room type (bedroom, living room, kitchen, etc.).
2. Based on the visual cues (windows, doors, furniture placement), estimate the current orientation.
3. Suggest directional corrections and furniture repositioning to align with Vaastu principles (e.g., bed head towards South/East, heavy furniture in South-West).
4. Provide a detailed layout suggestion that maintains spatial consistency.
Return the response in a structured format with "Analysis", "Suggestions", and "Layout Plan".
`;

export const SPACE_OPTIMIZATION_PROMPT = `
Analyze the provided room image for space optimization.
1. Detect clutter and identify furniture that makes the room feel small or cramped.
2. Suggest a minimalistic layout using furniture repositioning.
3. Apply color theory (e.g., light colors, mirrors, vertical lines) to visually enlarge the room.
4. Provide specific steps to transform the space into a more open and airy environment.
Return the response in a structured format with "Clutter Detection", "Repositioning Strategy", and "Visual Expansion Tips".
`;

export const SMART_LIGHTING_PROMPT = (mode: string) => `
Analyze the provided room image and simulate ${mode} lighting conditions.
1. Identify current light sources (windows, lamps, overhead lights).
2. Describe how ${mode} lighting (e.g., warm 2700K, cool 5000K, or ambient) would change the mood, shadows, and highlights in this specific room.
3. Suggest optimal placement for new smart lighting fixtures to enhance the ${mode} effect.
4. Optimize brightness levels and shadow depth for a realistic simulation.
Return the response in a structured format with "Current Assessment", "Lighting Simulation", and "Fixture Placement".
`;
