import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { VAASTU_PROMPT, SPACE_OPTIMIZATION_PROMPT, SMART_LIGHTING_PROMPT } from "../constants";

const getAI = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY is not set");
  return new GoogleGenAI({ apiKey });
};

export async function analyzeRoom(image: string, feature: 'vaastu' | 'space' | 'lighting', lightingMode?: string) {
  const ai = getAI();
  const model = "gemini-3-flash-preview";

  let prompt = "";
  if (feature === 'vaastu') prompt = VAASTU_PROMPT;
  else if (feature === 'space') prompt = SPACE_OPTIMIZATION_PROMPT;
  else if (feature === 'lighting') prompt = SMART_LIGHTING_PROMPT(lightingMode || 'ambient');

  const imagePart = {
    inlineData: {
      mimeType: "image/jpeg",
      data: image.split(',')[1], // Remove data:image/jpeg;base64,
    },
  };

  const response: GenerateContentResponse = await ai.models.generateContent({
    model,
    contents: [{ parts: [imagePart, { text: prompt }] }],
  });

  return response.text;
}

export async function enhanceImage(image: string, instruction: string) {
  const ai = getAI();
  // Using the image editing model
  const model = 'gemini-2.5-flash-image';

  const imagePart = {
    inlineData: {
      data: image.split(',')[1],
      mimeType: "image/jpeg",
    },
  };

  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        imagePart,
        { text: instruction },
      ],
    },
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
}
