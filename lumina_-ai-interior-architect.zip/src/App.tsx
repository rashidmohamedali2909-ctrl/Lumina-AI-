import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Upload, 
  Compass, 
  Maximize, 
  Lightbulb, 
  Loader2, 
  ChevronRight, 
  Sparkles,
  RefreshCcw,
  Image as ImageIcon
} from 'lucide-react';
import { cn } from './lib/utils';
import { analyzeRoom, enhanceImage } from './services/aiService';

type Feature = 'vaastu' | 'space' | 'lighting';

export default function App() {
  const [image, setImage] = useState<string | null>(null);
  const [enhancedImage, setEnhancedImage] = useState<string | null>(null);
  const [selectedFeature, setSelectedFeature] = useState<Feature>('vaastu');
  const [lightingMode, setLightingMode] = useState('warm');
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setImage(reader.result as string);
      setEnhancedImage(null);
      setAnalysis(null);
    };
    reader.readAsDataURL(file);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: onDrop as any,
    accept: { 'image/*': [] } as any,
    multiple: false
  } as any);

  const handleProcess = async () => {
    if (!image) return;
    setLoading(true);
    try {
      const result = await analyzeRoom(image, selectedFeature, lightingMode);
      setAnalysis(result || "No analysis generated.");
      
      // Attempt visual enhancement
      const enhancementInstruction = selectedFeature === 'lighting' 
        ? `Simulate ${lightingMode} lighting in this room. Make it look realistic with proper shadows and highlights.`
        : selectedFeature === 'space'
        ? "Show this room with a minimalistic layout, less clutter, and light colors to make it look bigger."
        : "Rearrange the furniture in this room to follow Vaastu principles, ensuring a balanced and harmonious layout.";
      
      const enhanced = await enhanceImage(image, enhancementInstruction);
      if (enhanced) setEnhancedImage(enhanced);
    } catch (error) {
      console.error(error);
      setAnalysis("An error occurred during processing. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-orange-500/30">
      {/* Background Atmosphere */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-orange-500/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-500/10 blur-[120px] rounded-full" />
      </div>

      <main className="relative z-10 max-w-7xl mx-auto px-6 py-12">
        {/* Header */}
        <header className="mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-3 mb-4"
          >
            <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/20">
              <Sparkles className="text-white w-6 h-6" />
            </div>
            <span className="text-sm font-mono tracking-widest uppercase text-orange-500">Interior Intelligence</span>
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-6xl md:text-8xl font-bold tracking-tighter mb-6"
          >
            LUMINA<span className="text-orange-500">.</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-zinc-400 max-w-2xl leading-relaxed"
          >
            Redefining spaces through multimodal reasoning. Upload your room and let our AI architect transform it with Vaastu wisdom, space optimization, and smart lighting.
          </motion.p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Left Column: Controls & Upload */}
          <div className="lg:col-span-5 space-y-8">
            {/* Feature Selection */}
            <section className="space-y-4">
              <h2 className="text-xs font-mono uppercase tracking-widest text-zinc-500">Select Feature</h2>
              <div className="grid grid-cols-1 gap-3">
                {[
                  { id: 'vaastu', icon: Compass, label: 'Vaastu Design Mode', desc: 'Cultural alignment & directional corrections' },
                  { id: 'space', icon: Maximize, label: 'Space Optimization', desc: 'Minimalistic layouts to enlarge rooms' },
                  { id: 'lighting', icon: Lightbulb, label: 'Smart Lighting Console', desc: 'Simulate ambient conditions' },
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setSelectedFeature(f.id as Feature)}
                    className={cn(
                      "flex items-start gap-4 p-4 rounded-2xl border transition-all duration-300 text-left group",
                      selectedFeature === f.id 
                        ? "bg-zinc-900 border-orange-500/50 shadow-lg shadow-orange-500/5" 
                        : "bg-zinc-900/50 border-zinc-800 hover:border-zinc-700"
                    )}
                  >
                    <div className={cn(
                      "p-2 rounded-lg transition-colors",
                      selectedFeature === f.id ? "bg-orange-500 text-white" : "bg-zinc-800 text-zinc-400 group-hover:text-zinc-200"
                    )}>
                      <f.icon size={20} />
                    </div>
                    <div>
                      <h3 className="font-medium text-zinc-100">{f.label}</h3>
                      <p className="text-sm text-zinc-500">{f.desc}</p>
                    </div>
                  </button>
                ))}
              </div>
            </section>

            {/* Lighting Options */}
            <AnimatePresence>
              {selectedFeature === 'lighting' && (
                <motion.section
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-4 overflow-hidden"
                >
                  <h2 className="text-xs font-mono uppercase tracking-widest text-zinc-500">Lighting Mode</h2>
                  <div className="flex flex-wrap gap-2">
                    {['warm', 'cool', 'ambient', 'daylight'].map((mode) => (
                      <button
                        key={mode}
                        onClick={() => setLightingMode(mode)}
                        className={cn(
                          "px-4 py-2 rounded-full text-sm font-medium transition-all",
                          lightingMode === mode 
                            ? "bg-orange-500 text-white" 
                            : "bg-zinc-900 text-zinc-400 hover:bg-zinc-800"
                        )}
                      >
                        {mode.charAt(0).toUpperCase() + mode.slice(1)}
                      </button>
                    ))}
                  </div>
                </motion.section>
              )}
            </AnimatePresence>

            {/* Upload Area */}
            <section className="space-y-4">
              <h2 className="text-xs font-mono uppercase tracking-widest text-zinc-500">Upload Room Image</h2>
              <div 
                {...getRootProps()} 
                className={cn(
                  "relative aspect-video rounded-3xl border-2 border-dashed transition-all cursor-pointer flex flex-center items-center justify-center overflow-hidden group",
                  isDragActive ? "border-orange-500 bg-orange-500/5" : "border-zinc-800 bg-zinc-900/30 hover:border-zinc-700"
                )}
              >
                <input {...getInputProps()} />
                {image ? (
                  <>
                    <img src={image} alt="Room" className="w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity" referrerPolicy="no-referrer" />
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="bg-white/10 backdrop-blur-md px-4 py-2 rounded-full flex items-center gap-2">
                        <RefreshCcw size={16} />
                        <span className="text-sm font-medium">Change Image</span>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 bg-zinc-800 rounded-2xl flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                      <Upload className="text-zinc-500 group-hover:text-orange-500 transition-colors" />
                    </div>
                    <p className="text-zinc-500 text-sm">Drag & drop or click to upload</p>
                  </div>
                )}
              </div>
            </section>

            <button
              disabled={!image || loading}
              onClick={handleProcess}
              className={cn(
                "w-full py-4 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 transition-all shadow-xl",
                !image || loading 
                  ? "bg-zinc-800 text-zinc-500 cursor-not-allowed" 
                  : "bg-orange-500 text-white hover:bg-orange-600 shadow-orange-500/20 active:scale-[0.98]"
              )}
            >
              {loading ? (
                <>
                  <Loader2 className="animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  Transform Space
                  <ChevronRight size={20} />
                </>
              )}
            </button>
          </div>

          {/* Right Column: Results */}
          <div className="lg:col-span-7 space-y-8">
            <AnimatePresence mode="wait">
              {!analysis && !loading ? (
                <motion.div 
                  key="placeholder"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full min-h-[400px] flex flex-col items-center justify-center text-center p-12 bg-zinc-900/20 rounded-3xl border border-zinc-800/50"
                >
                  <div className="w-20 h-20 bg-zinc-800/50 rounded-full flex items-center justify-center mb-6">
                    <ImageIcon className="text-zinc-600" size={32} />
                  </div>
                  <h3 className="text-2xl font-medium text-zinc-300 mb-2">Awaiting Transformation</h3>
                  <p className="text-zinc-500 max-w-sm">Upload an image and select a feature to see the AI architect's magic in real-time.</p>
                </motion.div>
              ) : (
                <motion.div 
                  key="results"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="space-y-8"
                >
                  {/* Visual Result */}
                  <section className="space-y-4">
                    <h2 className="text-xs font-mono uppercase tracking-widest text-zinc-500">Visual Enhancement</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <span className="text-[10px] font-mono uppercase text-zinc-600">Original</span>
                        <div className="aspect-square rounded-2xl overflow-hidden border border-zinc-800">
                          <img src={image!} alt="Original" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <span className="text-[10px] font-mono uppercase text-orange-500">AI Enhanced</span>
                        <div className="aspect-square rounded-2xl overflow-hidden border border-orange-500/30 bg-zinc-900 flex items-center justify-center relative">
                          {loading ? (
                            <div className="flex flex-col items-center gap-3">
                              <Loader2 className="animate-spin text-orange-500" />
                              <span className="text-xs text-zinc-500">Rendering...</span>
                            </div>
                          ) : enhancedImage ? (
                            <img src={enhancedImage} alt="Enhanced" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          ) : (
                            <span className="text-xs text-zinc-600">No visual preview available</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </section>

                  {/* Text Analysis */}
                  <section className="space-y-4">
                    <h2 className="text-xs font-mono uppercase tracking-widest text-zinc-500">Architectural Analysis</h2>
                    <div className="bg-zinc-900/50 border border-zinc-800 rounded-3xl p-8 prose prose-invert max-w-none">
                      {loading ? (
                        <div className="space-y-4">
                          <div className="h-4 bg-zinc-800 rounded w-3/4 animate-pulse" />
                          <div className="h-4 bg-zinc-800 rounded w-1/2 animate-pulse" />
                          <div className="h-4 bg-zinc-800 rounded w-5/6 animate-pulse" />
                        </div>
                      ) : (
                        <div className="whitespace-pre-wrap text-zinc-300 leading-relaxed font-light">
                          {analysis}
                        </div>
                      )}
                    </div>
                  </section>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-zinc-900 text-center">
        <p className="text-zinc-600 text-sm font-mono">
          &copy; 2026 LUMINA ARCHITECTURAL INTELLIGENCE. POWERED BY GEMINI MULTIMODAL REASONING.
        </p>
      </footer>
    </div>
  );
}
